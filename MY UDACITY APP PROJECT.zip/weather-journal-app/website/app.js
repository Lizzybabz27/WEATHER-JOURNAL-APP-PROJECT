// FOLLOWING THE UDACITY WEATHER JOURNAL APP RUBRIC AND THE 'COMMENTS ONLY' FILES
// AS WELL AS THE DEVELOPMENT STRATEGY

// S T A R T   BY FETCHING THE WEB API

const howToPlaceYourUrl = "https://api.openweathermap.org/data/2.5/weather?zip={zip code}&appid={API key}";
const myBaseURI         = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const myAppApiKey       = '&appid=824dae3a60cbe34559b3a822f28c36da&units=imperial';

 
// using querySelector, we have
const zipFolder      = document.querySelector("#zip");
const feelingsFolder = document.querySelector("#feelings");
const ofImportance   = document.querySelector("generate");


// now, converting the date to a string
const first = new Date();
const date = first.toDateString(); 


// using getElementById, we have
const weatherTemperature = document.getElementById('temp'); 
const getMyDate  = document.getElementById('date'); 
const nameFolder = document.getElementById('name');
const container  = document.getElementById('content');
const humidity   = document.getElementById('weatherOne');
const pressure   = document.getElementById('weatherTwo');
const windSpeed  = document.getElementById('weatherThree');




// THSI IS AN EVENT LISTENER WITH THE ID GENERATE, ACCESSSED THROUGH THE QUERYSELECTOR METHOD
// add the event listener to listen for a click event in the generate button
document.querySelector("#generate").addEventListener('click', (functionToGenerate) => {
    //prevent the default using the '.preventDefault' function
functionToGenerate.preventDefault()

// add the URL and get the data
// THIS VARIABLE IS USED TO CALL THE ASYNC GET REQUEST WITH THESE PARAMETERS
const listenToUri = myBaseURI + zipFolder.value + myAppApiKey // 




// CHAIN ALL THE PROMISES TOGETHER USING '.then'
firstPromiseData(listenToUri)                 .then((awaitingTwo) => {               
secondPromiseData(awaitingTwo)                .then((whatWeNeed)  => {                   
thirdPromiseData('/postTheData', whatWeNeed)  .then(()            => {
fourthPromiseData('/getTheData')              .then((collection)  => {           
clientSideUpdate(collection) }); }); }); }) });




// USING THE ASYNC FUNCTIONS TO CREATE PROMISES
// now create different functions that are promises 
 
//  firstPomiseData = THIS IS AN ASYNC FUNCTION THAT USES fetch() TO MAKE A GET REQUEST TO THE OPENWEATHERMAP API
//                  = USED TO COLLECT THE DATA WE NEED FROM THE 'OPENWEATHERMAP.ORG' THROUGH THE myBaseURL
const firstPromiseData = async(fetchUrl) => {
    try{ const awaitingOne = await fetch(fetchUrl);
        const awaitingTwo = await awaitingOne.json();
        if(awaitingTwo.cod == 200) {console.log(awaitingTwo)}
        else console.log(awaitingTwo.message) 
            return awaitingTwo;} 
    catch(errorOne){ console.log(errorOne);}}


// secondPromiseData = USED TO SPECIFICALLY COLLECT THE DATA WE PARTICULARLY WANT
const secondPromiseData = async(awaitingTwo) =>{
    try{
        if(awaitingTwo.message){ return awaitingTwo; }
        else { const whatWeNeed = { feelingsFolder: feelings.value, date:date, weatherTemperature: awaitingTwo.main.temp, nameFolder : awaitingTwo.name,
         humidity:humidity.value, pressure:pressure.value, windSpeed:windSpeed.value}
            return whatWeNeed;} }
    catch(errorTwo){ (console.error(errorTwo))}}


// thirdPromiseData = USED TO TRANSFER DATA TO THE GET ROUTE CREATED IN THE SERVER
const thirdPromiseData = async(fetchUrl = "", takeIn={}) => {
    // create a variable for the fetch
            const giveOut = await fetch(fetchUrl, {method: "POST", credentials: "same-origin", headers: {"Content-Type": "application/json"}, body: JSON.stringify(takeIn)});
    try{ const reliable = await giveOut.json();   // try it without errors
         return reliable;}                     
    catch(errorThree){ console.log(errorThree);}}  // if there is an error, catch it


// fourthPromiseData = USED TO COLLECT DATA FROM THE SERVER BY USING THE URL
const fourthPromiseData = async(fetchUrl) => { const collection = await fetch(fetchUrl);
    // create a variable for the fetch
    try{ const collectable = await collection.json();  // try it without errors  
         console.log(collectable);
         return collectable;}   
    catch(errorFour){console.error(errorFour);}}   // if there is an error, catch it






// clientSideUpdate = USED TO COLLECT ALL THE DATA WE HAVE ACCESSED AND 
//                   SHOWCASE THEM ON THE APP WHICH IS THE CLIENTSIDE
const clientSideUpdate = async() => {const  finalFetch = await fetch('/getTheData');   
    try{ const everythingShown = await finalFetch.json();    
            console.log(everythingShown);
        if (everythingShown.date){ const icon = everythingShown.icon; 

                    backGround(icon);
    
                    nameFolder.innerHTML         = `${everythingShown.nameFolder}.`;
                    getMyDate.innerHTML          = `${everythingShown.date}.`;
                    weatherTemperature.innerHTML = `${everythingShown.weatherTemperature}°C`;
                    container.innerHTML          =  everythingShown.feelingsFolder? everythingShown.feelingsFolder: 'Please Express your Feelings for today.';
                    
 // USE THE QUERY SELECTOR TO ACCESS THE DOM ELEMENTS                   
                    document.querySelector(".entryHolder").style.display = 'block';
                    document.querySelector("#error").style.display = 'none' }
        else {
                    document.querySelector("#error").innerHTML = everythingShown.message;
                    document.querySelector(".entryHolder").style.display = 'none';
                    document.querySelector("#error").style.display = "block" ; }}
    catch(lastError){ console.log('error,,: '+ lastError);}}


// working on the bakground, to make it interactive on different devices, we have these:
const backGround = async (icon) => {
    await icon;
    if (icon == "03d" || icon == "04d" || icon == "03n" || icon == "04n"){
        let picture = document.querySelector("body");
        picture.style.backgroundImage = "url('https://images.unsplash.com/photo-1551376347-075b0121a65b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80')";
        picture.style.backgroundRepeat = "no-repeat";
        picture.style.backgroundSize = "cover";
    }
    else if (icon == "09d" || icon == "10d" || icon == "09n" || icon == "10n") {
        let picture = document.querySelector("body");
        picture.style.backgroundImage = "url('https://images.unsplash.com/photo-1505159940484-eb2b9f2588e2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80')";
        picture.style.backgroundRepeat = "no-repeat";
        picture.style.backgroundSize = "cover";
} 
    else if (icon == "11d" || icon == "11n") {
        let picture = document.querySelector("body");
        picture.style.backgroundImage = "url('https://images.unsplash.com/photo-1495107334309-fcf20504a5ab?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80')";
        picture.style.backgroundRepeat = "no-repeat";
        picture.style.backgroundSize = "cover";
    }
    else if (icon == "13d" || icon == "13n") {
        let picture = document.querySelector("body");
        picture.style.backgroundImage =  "url('https://images.unsplash.com/photo-1484591974057-265bb767ef71?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80')";
        picture.style.backgroundRepeat = "no-repeat";
        picture.style.backgroundSize = "cover";
    }
    else if(icon == "50d" || icon == "50n"){
        let picture = document.querySelector("body");
        picture.style.backgroundImage = "url('https://images.unsplash.com/photo-1484591974057-265bb767ef71?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80')";  
        picture.style.backgroundRepeat = "no-repeat";
        picture.style.backgroundSize = "cover";  
        
        
    } else {
        let picture = document.querySelector("body");
        picture.style.backgroundImage = "url('https://source.unsplash.com/random/900×700/?landscape')"; 
        picture.style.backgroundRepeat = "no-repeat";
        picture.style.backgroundSize = "cover";  
    }
}

