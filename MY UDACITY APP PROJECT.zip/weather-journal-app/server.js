
// FOLLOWING THE WEATHER JOURNAL PROJECT RUBRIC

// THIS SERVER IS CREATED TO RECIEVE REQUESTS, PROCCESS THE REQUEST AND RETURN A RESPONSE

// START BY SETTING UP THE PROJECT ENVIRONMENT

//  we have set the variables and require all the packages
const myPort = 8089;




// create an array to hold the weather data
projectData = []; // this is the object


// REQUIRE ALL THE PACKAGES
// set the variable express to run the server and routes
// EXPRESS
const express = require('express');
const myApp = express();


// BODY-PARSER
// set the body-parser variable and request for it
const bodyParser = require('body-parser');

// require for the cors packeage which would allow the browser and server talk to each other without intteruption
const cors = require('cors');
myApp.use(cors());


// for the middleware, make use of the 'app.use' method
myApp.use(bodyParser.urlencoded({extended:false}));
myApp.use(bodyParser.json());


// now, initialize the main project folder which is 'website'
// THIS SIMPLE LINE OF CODE CONNECTS THE SERVER AND THE CLIENTS CODE
myApp.use(express.static('website'));


//------------------------------------------
// ROUTES AND GET REQUESTS
// (1) GET REQUEST
// now, respond with javascript object when a GET request is made to the home page.
myApp.get('/getTheData', async (request, response) => { console.log(projectData);
     response.send(projectData);})

myApp.get('/getTheData', getMyRequest);
     function getMyRequest(request, response){
            response.send(projectData);
     projectData = []; }


// (2) POST REQUESTSs
// create post() with url and call back function
myApp.post('/postTheData', async (request,response) => { const postThisNow = await request.body;    
       projectData = postThisNow;
       console.log(projectData);
       response.status(200).send(projectData)});

myApp.post('/postTheData', postMyRequest);
  function postMyRequest (request, response) {console.log(request.body);    
    newClientData = { date: request.body.date, weatherTemperature: request.temp, container: request.body.content  }
    projectData.push(newClientData); }


// next, set a variable named server and pass the listen method
// the port arguement and the callback function
myApp.listen(myPort, attention);
        function attention(){console.log('server is running');
               console.log('it is currently running on localhost' +  myPort);}

